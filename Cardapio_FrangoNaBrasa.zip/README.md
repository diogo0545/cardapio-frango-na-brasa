# Cardápio Frango na Brasa
Este é o site do cardápio do restaurante **Frango na Brasa**, integrado com Google Sheets.

## Como usar
1. Suba o `index.html` no GitHub Pages ou Netlify.
2. Certifique-se de que a planilha do Google Sheets está **publicada na web**.
3. Atualize o cardápio diariamente na planilha.
4. Compartilhe o link do site com os clientes. Eles verão automaticamente os pratos do dia + itens fixos + botão para pedir via WhatsApp.

## Estrutura da planilha
| date       | category | name                     | description                     | price   |
|------------|----------|--------------------------|---------------------------------|---------|
| 2025-10-22 | daily    | Marmita do Dia - Frango  | Arroz, feijão, salada           | R$ 20,00|
| -          | fixed    | Frango Inteiro Assado    | Inteiro na brasa                | R$ 35,00|
